import React from 'react'

const BoardPage = () => {
  return (
    <>
      <h2>게시판 페이지</h2>
    </>
  )
}
export default BoardPage
