import Footer from "../include/Footer"
import Header from "../include/Header"

const HomePage = () => {
  return (
    <>
      <Header />
      <div>HomePage</div>
      <Footer />
    </>
  )
}

export default HomePage